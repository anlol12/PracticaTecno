from django.shortcuts import render

def regis_login(request):
    return render(request,'registro_login.html')