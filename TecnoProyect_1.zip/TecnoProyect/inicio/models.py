from django.db import models

class empleado(models.Model):
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)

class departamento(models.Model):
    departamento = models.CharField(max_length=100)
    nombre = models.CharField(max_length=100)
    descripcion = models.CharField(max_length=100)
    ubicacion = models.CharField(max_length=100)

class marca(models.Model):
    nombre = models.CharField(max_length=100)
    descripcion = models.CharField(max_length=100)

class modelo(models.Model):
    modelo = models.CharField(max_length=100)
    descripcion = models.CharField(max_length=100)

class sucursal(models.Model):
    nombre = models.CharField(max_length=100)
    ubicacion = models.CharField(max_length=100)
    codigo = models.CharField(max_length=100)
