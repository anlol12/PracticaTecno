from django.db import models
from registro_login.models import usuarios 

class venta(models.Model):
    id_ventas = models.AutoField(primary_key=True)
    fecha = models.CharField(max_length=100)
    total = models.CharField(max_length=100)
    idUser = models.ForeignKey(usuarios, on_delete=models.CASCADE)
    idDetalleVen = models.OneToOneField('detalleVenta', on_delete=models.CASCADE, related_name= 'venta')

class detalleVenta(models.Model):
    idDetalleVe = models.AutoField(primary_key=True)
    metodo = models.CharField(max_length=100)