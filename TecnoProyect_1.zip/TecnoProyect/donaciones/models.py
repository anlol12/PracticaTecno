from django.db import models

class donaciones(models.Model):
    num_aquipo = models.CharField(max_length=100)
    donador = models.CharField(max_length=100)
    estado = models.CharField(max_length=100)