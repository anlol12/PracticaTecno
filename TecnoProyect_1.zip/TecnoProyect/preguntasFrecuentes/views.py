from django.shortcuts import render

def preguntasFre(request):
    return render(request,'preguntasFre.html')