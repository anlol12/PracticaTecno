from django.apps import AppConfig


class PreguntasfrecuentesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'preguntasFrecuentes'
