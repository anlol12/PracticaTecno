from django.db import models

class repaciones(models.Model):
    descripcion = models.CharField(max_length=100)
    fecha = models.CharField(max_length=100)

class estado(models.Model):
    estado_equipo = models.CharField(max_length=100)
    fecha_equipo = models.CharField(max_length=100)
    descripcion = models.CharField(max_length=100)

class reclamo(models.Model):
    fecha = models.CharField(max_length=100)
    descripcion = models.CharField(max_length=100)

class respuesta_reclamo(models.Model):
    fecha = models.CharField(max_length=100)
    respuesta = models.CharField(max_length=100)
