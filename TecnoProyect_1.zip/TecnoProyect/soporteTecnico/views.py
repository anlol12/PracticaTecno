from django.shortcuts import render

def soporteTecnico(request):
    return render(request, "soporteTecnico.html")